<div class="row-fluid">
    {!! $this->renderCalendar() !!}
</div>

